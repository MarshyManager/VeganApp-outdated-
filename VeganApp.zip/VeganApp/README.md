# VeganApp
Android application for vegans and vegetarians
